
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `absences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `absences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_absence` date NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `to` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `absences` WRITE;
/*!40000 ALTER TABLE `absences` DISABLE KEYS */;
/*!40000 ALTER TABLE `absences` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `academics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `academics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `academics` WRITE;
/*!40000 ALTER TABLE `academics` DISABLE KEYS */;
/*!40000 ALTER TABLE `academics` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `announcement_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcement_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `announcement_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `announcement_user` WRITE;
/*!40000 ALTER TABLE `announcement_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcement_user` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `academic_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gestion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date_announcement` date NOT NULL,
  `end_date_announcement` date NOT NULL,
  `start_date_calification` date NOT NULL,
  `end_date_calification` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `announcements_description_unique` (`description`),
  KEY `announcements_academic_id_foreign` (`academic_id`),
  KEY `announcements_item_id_foreign` (`item_id`),
  CONSTRAINT `announcements_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `academics` (`id`) ON DELETE CASCADE,
  CONSTRAINT `announcements_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `areas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic_id` int(10) unsigned NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `areas_academic_id_foreign` (`academic_id`),
  CONSTRAINT `areas_academic_id_foreign` FOREIGN KEY (`academic_id`) REFERENCES `academics` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `areas` WRITE;
/*!40000 ALTER TABLE `areas` DISABLE KEYS */;
/*!40000 ALTER TABLE `areas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `asignature_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asignature_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asignature_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asignature_groups_asignature_id_foreign` (`asignature_id`),
  CONSTRAINT `asignature_groups_asignature_id_foreign` FOREIGN KEY (`asignature_id`) REFERENCES `asignatures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `asignature_groups` WRITE;
/*!40000 ALTER TABLE `asignature_groups` DISABLE KEYS */;
INSERT INTO `asignature_groups` VALUES (1,'2',12,'2020-12-11 23:48:06','2020-12-11 23:48:06'),(2,'2',13,'2020-12-11 23:48:06','2020-12-11 23:48:06'),(3,'3',13,'2020-12-11 23:48:06','2020-12-11 23:48:06'),(4,'2',31,'2020-12-11 23:48:06','2020-12-11 23:48:06'),(5,'2',30,'2020-12-11 23:48:06','2020-12-11 23:48:06'),(6,'1',33,'2020-12-11 23:48:06','2020-12-11 23:48:06');
/*!40000 ALTER TABLE `asignature_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `asignature_groups_teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asignature_groups_teachers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `teacher` int(10) unsigned NOT NULL,
  `titular` tinyint(1) NOT NULL DEFAULT 1,
  `schedule` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asignature_groups_teachers_group_id_foreign` (`group_id`),
  KEY `asignature_groups_teachers_teacher_foreign` (`teacher`),
  KEY `asignature_groups_teachers_schedule_foreign` (`schedule`),
  CONSTRAINT `asignature_groups_teachers_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `asignature_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asignature_groups_teachers_schedule_foreign` FOREIGN KEY (`schedule`) REFERENCES `schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asignature_groups_teachers_teacher_foreign` FOREIGN KEY (`teacher`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `asignature_groups_teachers` WRITE;
/*!40000 ALTER TABLE `asignature_groups_teachers` DISABLE KEYS */;
/*!40000 ALTER TABLE `asignature_groups_teachers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `asignatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asignatures` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `asignatures` WRITE;
/*!40000 ALTER TABLE `asignatures` DISABLE KEYS */;
INSERT INTO `asignatures` VALUES (1,'calculo 1','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(2,'calculo 2','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(3,'calculo 3','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(4,'ecuaciones diferenciales','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(5,'algebra','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(6,'algebra 2','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(7,'algebra matricial','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(8,'matematica discreta','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(9,'fisica','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(10,'fisica 2','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(11,'fisica 3','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(12,'introduccion a la programacion','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(13,'elementos de programacion','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(14,'taller de programacion','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(15,'base de datos','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(16,'base de datos 2','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(17,'taller base de datos','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(18,'redes','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(19,'redes avanzadas','2020','II','2020-12-11 23:48:05','2020-12-11 23:48:05'),(20,'sistemas de informacion','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(21,'sistemas de informacion 2','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(22,'ingles','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(23,'ingles 2','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(24,'ingles 3','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(25,'perfil','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(26,'taller de grado','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(27,'taller de grado 2','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(28,'inteligencia artificial','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(29,'inteligencia artificial 2','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(30,'taller de ingenieria de software','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(31,'arquitectura de computadoras','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(32,'grafos','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06'),(33,'algoritmos avanzados','2020','II','2020-12-11 23:48:06','2020-12-11 23:48:06');
/*!40000 ALTER TABLE `asignatures` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auditable_id` int(10) unsigned NOT NULL,
  `auditable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_values` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_values` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audits_auditable_id_auditable_type_index` (`auditable_id`,`auditable_type`),
  KEY `audits_user_id_user_type_index` (`user_id`,`user_type`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `audits` WRITE;
/*!40000 ALTER TABLE `audits` DISABLE KEYS */;
INSERT INTO `audits` VALUES (1,'App\\User',1,'updated',1,'App\\User','{\"remember_token\":\"\"}','{\"remember_token\":\"Co2kDuDhqsTpO4ALlled4K0BgLxKZWURrbZE3gUC5akx8Pw5kT8t8tUWFYoi\"}','http://localhost:8000/logout?','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',NULL,'2020-12-11 23:49:11','2020-12-11 23:49:11'),(2,'App\\User',1,'deleted',6,'App\\User','{\"id\":6,\"name\":\"Noone\",\"lastname\":\"noname\",\"lastnamemother\":null,\"phone\":\"5555555\",\"address\":null,\"nro_docs\":null,\"auxiliar_name\":null,\"gender\":\"M\",\"ci\":\"78975456\",\"cod_sis\":\"201752145\",\"email\":\"noname@noname.com\",\"password\":\"$2y$10$7D\\/bXDmSSmK29Kf3zKMbhO86zeCCA6qemKzLgS6B6WwehgUHwlFjq\",\"direction\":null,\"name_matter\":null,\"status\":\"HABILITADO\",\"observations\":null,\"remember_token\":\"\"}','[]','http://localhost:8000/admin/users/6?','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',NULL,'2020-12-11 23:49:25','2020-12-11 23:49:25'),(3,'App\\User',1,'deleted',5,'App\\User','{\"id\":5,\"name\":\"Maggie\",\"lastname\":\"Simpson\",\"lastnamemother\":null,\"phone\":\"5555555\",\"address\":null,\"nro_docs\":null,\"auxiliar_name\":null,\"gender\":\"F\",\"ci\":\"78975456\",\"cod_sis\":\"201752145\",\"email\":\"maggie@maggie.com\",\"password\":\"$2y$10$C3jCqh7zqQ6Q8zaXN.PswOQN9\\/dDVxqV3\\/5tUr9.Elhj.X3enSosK\",\"direction\":null,\"name_matter\":null,\"status\":\"HABILITADO\",\"observations\":null,\"remember_token\":\"\"}','[]','http://localhost:8000/admin/users/5?','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',NULL,'2020-12-11 23:49:38','2020-12-11 23:49:38'),(4,'App\\User',1,'updated',1,'App\\User','{\"remember_token\":\"Co2kDuDhqsTpO4ALlled4K0BgLxKZWURrbZE3gUC5akx8Pw5kT8t8tUWFYoi\"}','{\"remember_token\":\"Gu3zvmPvkJ5O9jTd2MmhuP3l2iS2V7UVTqegzBF8XUQtae3bnoBB7DPWYCy1\"}','http://localhost:8000/logout?','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',NULL,'2020-12-11 23:49:53','2020-12-11 23:49:53'),(5,'App\\User',1,'deleted',4,'App\\User','{\"id\":4,\"name\":\"Lisa\",\"lastname\":\"Simpson\",\"lastnamemother\":null,\"phone\":\"2324422\",\"address\":null,\"nro_docs\":null,\"auxiliar_name\":null,\"gender\":\"F\",\"ci\":\"78975456\",\"cod_sis\":\"201752145\",\"email\":\"lisa@lisa.com\",\"password\":\"$2y$10$z9VUAsyFirZ9i\\/8hAmohEuyqLlF1RB408Aq9SIIaTv\\/oeegPRxoB.\",\"direction\":null,\"name_matter\":null,\"status\":\"HABILITADO\",\"observations\":null,\"remember_token\":\"\"}','[]','http://localhost:8000/admin/users/4?','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',NULL,'2020-12-11 23:50:10','2020-12-11 23:50:10'),(6,'App\\User',1,'deleted',1,'App\\Models\\Schedule','{\"id\":1,\"from\":\"06:45\",\"to\":\"08:15\",\"day\":\"LU\"}','[]','http://localhost:8000/admin/schedules/1?','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',NULL,'2020-12-11 23:50:18','2020-12-11 23:50:18'),(7,'App\\User',1,'updated',3,'App\\User','{\"direction\":null}','{\"direction\":\"petrolera\"}','http://localhost:8000/admin/users/3?','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',NULL,'2020-12-11 23:50:36','2020-12-11 23:50:36'),(8,'App\\User',1,'deleted',3,'App\\User','{\"id\":3,\"name\":\"Homero\",\"lastname\":\"Simpson\",\"lastnamemother\":null,\"phone\":\"5555555\",\"address\":null,\"nro_docs\":null,\"auxiliar_name\":null,\"gender\":\"M\",\"ci\":\"78975456\",\"cod_sis\":\"201752145\",\"email\":\"homero@homero.com\",\"password\":\"$2y$10$kOb8QOxAtugpljgNr32m5eomLoygs2q9BY8cOLeR5c\\/C3H4vHqcty\",\"direction\":\"petrolera\",\"name_matter\":null,\"status\":\"HABILITADO\",\"observations\":null,\"remember_token\":\"\"}','[]','http://localhost:8000/admin/users/3?','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',NULL,'2020-12-11 23:50:58','2020-12-11 23:50:58'),(9,'App\\User',1,'deleted',2,'App\\Models\\Schedule','{\"id\":2,\"from\":\"08:15\",\"to\":\"09:45\",\"day\":\"LU\"}','[]','http://localhost:8000/admin/schedules/2?','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',NULL,'2020-12-11 23:56:20','2020-12-11 23:56:20'),(10,'App\\User',1,'deleted',2,'App\\User','{\"id\":2,\"name\":\"Bart\",\"lastname\":\"Simpson\",\"lastnamemother\":null,\"phone\":\"54564646\",\"address\":null,\"nro_docs\":null,\"auxiliar_name\":null,\"gender\":\"M\",\"ci\":\"78975554\",\"cod_sis\":\"201752178\",\"email\":\"bart@gmail.com\",\"password\":\"$2y$10$Tt7y7QXwMw\\/luPpxNBFVMenjjZKZ09Sk2RLlYvXWrApwjkxuSixkS\",\"direction\":null,\"name_matter\":null,\"status\":\"HABILITADO\",\"observations\":null,\"remember_token\":\"\"}','[]','http://localhost:8000/admin/users/2?','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',NULL,'2020-12-11 23:58:03','2020-12-11 23:58:03'),(11,'App\\User',1,'updated',1,'App\\User','{\"remember_token\":\"Gu3zvmPvkJ5O9jTd2MmhuP3l2iS2V7UVTqegzBF8XUQtae3bnoBB7DPWYCy1\"}','{\"remember_token\":\"JRAqz9vcjlq4oXqx0twkkel1BWHY5Gq9bdZfWybTKRTSbaVhfA4EjLfg8Zat\"}','http://localhost:8000/logout?','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',NULL,'2020-12-11 23:58:56','2020-12-11 23:58:56'),(12,'App\\User',1,'updated',1,'App\\User','{\"remember_token\":\"JRAqz9vcjlq4oXqx0twkkel1BWHY5Gq9bdZfWybTKRTSbaVhfA4EjLfg8Zat\"}','{\"remember_token\":\"NMn10DhvhSa85HyPXa9ScQCTVdcbHl6wsd78eI3vCXbgWohHYVPSscn9ubLh\"}','http://localhost:8000/logout?','127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36',NULL,'2020-12-11 23:59:10','2020-12-11 23:59:10');
/*!40000 ALTER TABLE `audits` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `authorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authorities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `area_id` int(10) unsigned NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `authorities_area_id_foreign` (`area_id`),
  CONSTRAINT `authorities_area_id_foreign` FOREIGN KEY (`area_id`) REFERENCES `areas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `authorities` WRITE;
/*!40000 ALTER TABLE `authorities` DISABLE KEYS */;
/*!40000 ALTER TABLE `authorities` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `avisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `avisos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `avisos` WRITE;
/*!40000 ALTER TABLE `avisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `avisos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `califications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `califications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `announcement_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` double(8,2) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `califications_announcement_id_foreign` (`announcement_id`),
  CONSTRAINT `califications_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `califications` WRITE;
/*!40000 ALTER TABLE `califications` DISABLE KEYS */;
/*!40000 ALTER TABLE `califications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `classrooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classrooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asignature` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_suspended` date NOT NULL,
  `date_reposition` date NOT NULL,
  `from` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `to` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `classrooms` WRITE;
/*!40000 ALTER TABLE `classrooms` DISABLE KEYS */;
/*!40000 ALTER TABLE `classrooms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conditions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `announcement_id` int(10) unsigned NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `conditions_announcement_id_foreign` (`announcement_id`),
  CONSTRAINT `conditions_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `conditions` WRITE;
/*!40000 ALTER TABLE `conditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `conditions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `announcement_id` int(10) unsigned NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documents_announcement_id_foreign` (`announcement_id`),
  CONSTRAINT `documents_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `announcement_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `events_announcement_id_foreign` (`announcement_id`),
  CONSTRAINT `events_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `realname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `requirement_id` int(10) unsigned NOT NULL,
  `checked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `files_user_id_foreign` (`user_id`),
  KEY `files_requirement_id_foreign` (`requirement_id`),
  CONSTRAINT `files_requirement_id_foreign` FOREIGN KEY (`requirement_id`) REFERENCES `requirements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `teacher` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `destine` enum('DOCENCIA','LABORATORIO') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `knowledge_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `knowledge_ratings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `announcement_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` double(8,2) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `knowledge_ratings_announcement_id_foreign` (`announcement_id`),
  CONSTRAINT `knowledge_ratings_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `knowledge_ratings` WRITE;
/*!40000 ALTER TABLE `knowledge_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_ratings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (155,'2014_10_12_000000_create_users_table',1),(156,'2014_10_12_100000_create_password_resets_table',1),(157,'2019_11_08_144608_create_permission_tables',1),(158,'2019_11_08_181058_CreateAreasTable',1),(159,'2019_11_10_000311_CreateAnnouncemetsTable',1),(160,'2019_11_22_133949_CreateFilesTable',1),(161,'2020_06_07_171252_CreatePostulantsTable',1),(162,'2020_07_13_195732_CreateAvisosTable',1),(163,'2020_07_17_125054_CreateResultsTable',1),(164,'2020_07_19_200740_CreatePublishesTable',1),(165,'2020_11_09_112907_CreateSchedulesTable',1),(166,'2020_11_09_150549_create_asignatures_table',1),(167,'2020_11_09_180627_create_asignature_groups_table',1),(168,'2020_11_19_190950_create_week_reports_table',1),(169,'2020_11_20_001852_create_classrooms_table',1),(170,'2020_11_20_033012_create_absences_table',1),(171,'2020_12_11_132703_create_audits_table',1),(172,'2020_12_11_180736_create_user_session_histories_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'list users','2020-12-11 23:48:03','2020-12-11 23:48:03'),(2,'create users','2020-12-11 23:48:03','2020-12-11 23:48:03'),(3,'edit users','2020-12-11 23:48:03','2020-12-11 23:48:03'),(4,'delete users','2020-12-11 23:48:03','2020-12-11 23:48:03'),(5,'list roles','2020-12-11 23:48:03','2020-12-11 23:48:03'),(6,'create roles','2020-12-11 23:48:03','2020-12-11 23:48:03'),(7,'edit roles','2020-12-11 23:48:03','2020-12-11 23:48:03'),(8,'delete roles','2020-12-11 23:48:03','2020-12-11 23:48:03'),(9,'list areas','2020-12-11 23:48:04','2020-12-11 23:48:04'),(10,'create areas','2020-12-11 23:48:04','2020-12-11 23:48:04'),(11,'edit areas','2020-12-11 23:48:04','2020-12-11 23:48:04'),(12,'delete areas','2020-12-11 23:48:04','2020-12-11 23:48:04'),(13,'list academics','2020-12-11 23:48:04','2020-12-11 23:48:04'),(14,'create academics','2020-12-11 23:48:04','2020-12-11 23:48:04'),(15,'edit academics','2020-12-11 23:48:04','2020-12-11 23:48:04'),(16,'delete academics','2020-12-11 23:48:04','2020-12-11 23:48:04');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `postulants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postulants` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_id` int(11) NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nro_certificates` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nro_docs` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auxiliar_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ci` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cod_sis` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('HABILITADO','INHABILITADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HABILITADO',
  `observations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `postulants` WRITE;
/*!40000 ALTER TABLE `postulants` DISABLE KEYS */;
/*!40000 ALTER TABLE `postulants` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `publishes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publishes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `announcement_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `publishes` WRITE;
/*!40000 ALTER TABLE `publishes` DISABLE KEYS */;
/*!40000 ALTER TABLE `publishes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requirements` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `announcement_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `hours` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `destine` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `requirements_announcement_id_foreign` (`announcement_id`),
  CONSTRAINT `requirements_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `requirements` WRITE;
/*!40000 ALTER TABLE `requirements` DISABLE KEYS */;
/*!40000 ALTER TABLE `requirements` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `results` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `subitem_id` int(11) NOT NULL,
  `postulant_id` int(11) NOT NULL,
  `announcement_id` int(11) NOT NULL,
  `table` enum('MERIT','KNOWN') COLLATE utf8mb4_unicode_ci NOT NULL,
  `score_calification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `score_rating` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `results` WRITE;
/*!40000 ALTER TABLE `results` DISABLE KEYS */;
/*!40000 ALTER TABLE `results` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(2,1),(2,2),(2,3),(2,4),(2,5),(3,1),(3,2),(3,3),(3,4),(3,5),(4,1),(4,2),(4,3),(4,4),(4,5),(5,1),(5,2),(5,3),(5,4),(5,5),(6,1),(6,2),(6,3),(6,4),(6,5),(7,1),(7,2),(7,3),(7,4),(7,5),(8,1),(8,2),(8,3),(8,4),(8,5),(9,1),(9,2),(9,3),(9,4),(9,5),(10,1),(10,2),(10,3),(10,4),(10,5),(11,1),(11,2),(11,3),(11,4),(11,5),(12,1),(12,2),(12,3),(12,4),(12,5),(13,1),(13,2),(13,3),(13,4),(13,5),(14,1),(14,2),(14,3),(14,4),(14,5),(15,1),(15,2),(15,3),(15,4),(15,5),(16,1),(16,2),(16,3),(16,4),(16,5);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Admin','2020-12-11 23:48:03','2020-12-11 23:48:03'),(2,'Jefe de departamento','2020-12-11 23:48:03','2020-12-11 23:48:03'),(3,'Decano','2020-12-11 23:48:03','2020-12-11 23:48:03'),(4,'Director Académico','2020-12-11 23:48:03','2020-12-11 23:48:03'),(5,'DPA','2020-12-11 23:48:03','2020-12-11 23:48:03');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `from` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `to` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `day` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (3,'09:45','11:15','LU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(4,'11:15','12:45','LU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(5,'12:45','14:15','LU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(6,'14:15','15:45','LU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(7,'15:45','17:15','LU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(8,'17:15','18:45','LU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(9,'18:45','20:15','LU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(10,'20:15','21:45','LU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(11,'06:45','08:15','MA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(12,'08:15','09:45','MA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(13,'09:45','11:15','MA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(14,'11:15','12:45','MA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(15,'12:45','14:15','MA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(16,'14:15','15:45','MA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(17,'15:45','17:15','MA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(18,'17:15','18:45','MA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(19,'18:45','20:15','MA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(20,'20:15','21:45','MA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(21,'06:45','08:15','MI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(22,'08:15','09:45','MI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(23,'09:45','11:15','MI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(24,'11:15','12:45','MI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(25,'12:45','14:15','MI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(26,'14:15','15:45','MI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(27,'15:45','17:15','MI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(28,'17:15','18:45','MI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(29,'18:45','20:15','MI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(30,'20:15','21:45','MI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(31,'06:45','08:15','JU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(32,'08:15','09:45','JU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(33,'09:45','11:15','JU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(34,'11:15','12:45','JU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(35,'12:45','14:15','JU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(36,'14:15','15:45','JU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(37,'15:45','17:15','JU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(38,'17:15','18:45','JU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(39,'18:45','20:15','JU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(40,'20:15','21:45','JU','2020-12-11 23:48:05','2020-12-11 23:48:05'),(41,'06:45','08:15','VI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(42,'08:15','09:45','VI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(43,'09:45','11:15','VI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(44,'11:15','12:45','VI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(45,'12:45','14:15','VI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(46,'14:15','15:45','VI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(47,'15:45','17:15','VI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(48,'17:15','18:45','VI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(49,'18:45','20:15','VI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(50,'20:15','21:45','VI','2020-12-11 23:48:05','2020-12-11 23:48:05'),(51,'06:45','08:15','SA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(52,'08:15','09:45','SA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(53,'09:45','11:15','SA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(54,'11:15','12:45','SA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(55,'12:45','14:15','SA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(56,'14:15','15:45','SA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(57,'15:45','17:15','SA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(58,'17:15','18:45','SA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(59,'18:45','20:15','SA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(60,'20:15','21:45','SA','2020-12-11 23:48:05','2020-12-11 23:48:05'),(61,'06:45','08:15','DO','2020-12-11 23:48:05','2020-12-11 23:48:05'),(62,'08:15','09:45','DO','2020-12-11 23:48:05','2020-12-11 23:48:05'),(63,'09:45','11:15','DO','2020-12-11 23:48:05','2020-12-11 23:48:05'),(64,'11:15','12:45','DO','2020-12-11 23:48:05','2020-12-11 23:48:05'),(65,'12:45','14:15','DO','2020-12-11 23:48:05','2020-12-11 23:48:05'),(66,'14:15','15:45','DO','2020-12-11 23:48:05','2020-12-11 23:48:05'),(67,'15:45','17:15','DO','2020-12-11 23:48:05','2020-12-11 23:48:05'),(68,'17:15','18:45','DO','2020-12-11 23:48:05','2020-12-11 23:48:05'),(69,'18:45','20:15','DO','2020-12-11 23:48:05','2020-12-11 23:48:05'),(70,'20:15','21:45','DO','2020-12-11 23:48:05','2020-12-11 23:48:05');
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sub_califications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_califications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `calification_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` double(8,2) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_califications_calification_id_foreign` (`calification_id`),
  CONSTRAINT `sub_califications_calification_id_foreign` FOREIGN KEY (`calification_id`) REFERENCES `califications` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sub_califications` WRITE;
/*!40000 ALTER TABLE `sub_califications` DISABLE KEYS */;
/*!40000 ALTER TABLE `sub_califications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sub_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_ratings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rating_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `percentage` double(8,2) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sub_ratings_rating_id_foreign` (`rating_id`),
  CONSTRAINT `sub_ratings_rating_id_foreign` FOREIGN KEY (`rating_id`) REFERENCES `knowledge_ratings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sub_ratings` WRITE;
/*!40000 ALTER TABLE `sub_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `sub_ratings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_has_permissions` (
  `user_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`permission_id`),
  KEY `user_has_permissions_permission_id_foreign` (`permission_id`),
  CONSTRAINT `user_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_has_permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_has_permissions` WRITE;
/*!40000 ALTER TABLE `user_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_has_roles` (
  `role_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`user_id`),
  KEY `user_has_roles_user_id_foreign` (`user_id`),
  CONSTRAINT `user_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_has_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_has_roles` WRITE;
/*!40000 ALTER TABLE `user_has_roles` DISABLE KEYS */;
INSERT INTO `user_has_roles` VALUES (1,1);
/*!40000 ALTER TABLE `user_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_session_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_session_histories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event` enum('login','logout') COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_session_histories` WRITE;
/*!40000 ALTER TABLE `user_session_histories` DISABLE KEYS */;
INSERT INTO `user_session_histories` VALUES (1,1,'bSMHhPxs8GdnIGU6O6l65d2uGnNdrDp08YNl046H','logout','127.0.0.1','2020-12-11 23:49:11','2020-12-11 23:49:11'),(2,1,'uwypzNZtjEcuxxMWOJR09QhEenzWhlOMTD1J6YM9','login','127.0.0.1','2020-12-11 23:49:17','2020-12-11 23:49:17'),(3,1,'Ku2lYOQG6Byhb3IJa31NumhnETCzk34xIuMBWdW4','logout','127.0.0.1','2020-12-11 23:49:53','2020-12-11 23:49:53'),(4,1,'dBKSEa7mArJZ16EupVI7uv5Zq5ECVXjDPMcuol5o','login','127.0.0.1','2020-12-11 23:50:04','2020-12-11 23:50:04'),(5,1,'sLz6NWhed297qgh9aWoJiTVjazyUoLvlKkRdexk2','logout','127.0.0.1','2020-12-11 23:58:56','2020-12-11 23:58:56'),(6,1,'TwH9mcdA2slfj2q2FpY5QdeUy8TfqsjdSR3zgp9E','login','127.0.0.1','2020-12-11 23:59:01','2020-12-11 23:59:01'),(7,1,'NkVjwQ6cE3xDP2suqHpDyQhjMrUTOLSpXhvbBPLR','logout','127.0.0.1','2020-12-11 23:59:10','2020-12-11 23:59:10'),(8,1,'eKWMYiGE5WdIhQWrmAsB4eKiQzGEqgXVQ8dDSmUS','login','127.0.0.1','2020-12-12 07:40:27','2020-12-12 07:40:27'),(9,1,'mqabcfkzfUHcXwJrPx6Er5usI6XESbeJzwgeawlX','login','127.0.0.1','2020-12-12 16:18:29','2020-12-12 16:18:29');
/*!40000 ALTER TABLE `user_session_histories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastnamemother` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nro_docs` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auxiliar_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ci` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cod_sis` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_matter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('HABILITADO','INHABILITADO') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HABILITADO',
  `observations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrator','Admin',NULL,'1254646',NULL,NULL,NULL,'M','545646646','20150558255','admin@admin.com','$2y$10$9quS8jFESNWU1mZgEx7mheW7gAZautGCg2uuCcqfCffRE1zMatsra',NULL,NULL,'HABILITADO',NULL,'NMn10DhvhSa85HyPXa9ScQCTVdcbHl6wsd78eI3vCXbgWohHYVPSscn9ubLh','2020-12-11 23:48:05','2020-12-11 23:48:05');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `week_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `week_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `asignature` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `bodyclass` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `resourcesbody` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `observations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `has_file` tinyint(1) NOT NULL DEFAULT 0,
  `filename` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_path` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `week_reports` WRITE;
/*!40000 ALTER TABLE `week_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `week_reports` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

